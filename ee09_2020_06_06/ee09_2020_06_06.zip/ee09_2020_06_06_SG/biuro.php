<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl4.css">
    <title>Wycieczki krajoznawcze</title>
</head>

<body>
    <div class="gora">
        <h1>WITAMY W BIURZE PODRÓZY</h1>
    </div>
    <div class="dane">
        <h3>ARCHIWUM WYCIECZEK</h3>
        <?php
        $conn = mysqli_connect("localhost","root","","egzamin4");
        $query = "SELECT id, cel, cena FROM wycieczki WHERE dostepna = 0;";
        $lol = mysqli_query($conn,$query);
         
        while ($lol2 = mysqli_fetch_row($lol)){
            echo $lol2[0].$lol2[1] 
        }
        mysqli_close($conn);
        ?>
    </div>
    <div class="lewy">
        <h3>NATANIEJ</h3>
        <table>
            <tr>
                <td>Włochy</td>
                <td>od 1200 zł</td>
            </tr>
            <tr>
                <td>Francja</td>
                <td>od 1200 zł</td>
            </tr>
            <tr>
                <td>Hiszpania</td>
                <td>od 1400 zł</td>
            </tr>
        </table>
    </div>
    <div class="srodek">
        <h3>TU BYLIŚMY</h3>
        <!-- SKRYPT 2 -->
    </div>
    <div class="prawy">
        <h3>SKONTAKTUJ SIĘ</h3>
        <a href="mailto:wycieczki@wycieczki.pl"></a>
        <a href="tel:555666777"></a>
        <p>telefon 555666</p>
    </div>
    <div class="footer">
    <p>stronę wykonał:TWOJ TATA</p>
    </div>
</body>

</html>